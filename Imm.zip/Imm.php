<html>
<head>
    <title>homework</title>
</head>
<body>
    <div align="center">
        <fieldset align="center" style="width:50%">
            <legend> <h1>اضافة صورة</h1></legend>

            <form action="Imm.php" method="post" enctype="multipart/form-data">
		

                photo: <input type="file" name="mypoto">
                <br><br>
                <input type="submit" name="submit" value="show">
                <br><br>
            </form>
        </fieldset>
        <?php
			
			if (isset($_POST['submit'])){
				
				
				include 'coaa.php';
				$file_loc = 'img/';
				$filenama = time() . '_' . basename($_FILES["mypoto"]["name"]);
				$path = $file_loc . $filenama;
	
				move_uploaded_file ($_FILES ["mypoto"]["tmp_name"],$path);
				$sql = "insert into imgs(im) values ('$path')";
				if (mysqli_query($coaa,$sql)){
					echo "car new info has been inserte";
				}
				else{
					echo "errortt";
				}
			}
			?>
    </div>
</body>
</html>
